﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BioloidRobot
{
    public partial class frmMain : Form
    {
        private System.ComponentModel.BackgroundWorker bk1;
        public frmMain()
        {
            InitializeComponent();
            InitializeBackgroundWorker();
        }

        private void InitializeBackgroundWorker()
        {
            bk1 = new BackgroundWorker();
            bk1.WorkerReportsProgress = true;
            bk1.DoWork += new DoWorkEventHandler(Bk1_DoWork);
            bk1.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bk1_RunWorkerCompleted);
            bk1.ProgressChanged += new ProgressChangedEventHandler(Bk1_ProgressChanged);
        }

        private void Bk1_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            sb.AppendLine("Simulation is started now!");
            sb.AppendLine("Please wait... (until the simulation process will be completed!)");
            txtVRepMessage.Text = sb.ToString();
        }

        private void Bk1_DoWork(object sender, DoWorkEventArgs e)
        {
            BackgroundWorker worker = sender as BackgroundWorker;

            string res = StartVRepSimulation(worker);
            e.Result = res;
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            txtVRepMessage.Text = String.Empty;
        }

        
        StringBuilder sb = new StringBuilder();

        private void btnStartSimulation_Click(object sender, EventArgs e)
        {
            btnStartSimulation.Enabled = false;
            sb.AppendLine("The process started");

            txtVRepMessage.Text = sb.ToString();

            if (!bk1.IsBusy)
            {
                bk1.RunWorkerAsync(sb);
            }            

            //Bioloid robot = new Bioloid();

            //robot.SetVRepPort(Convert.ToInt32(txtPort.Text.ToString()));

            //robot.AddJoint(1, 0, 0, false);
            //robot.AddJoint(2, 0, 0, false);
            //robot.AddJoint(3, 0, 0, false);

            //Dictionary<int, int[]> servoMotions = new Dictionary<int, int[]>();
            //servoMotions.Add(1, new int[] { 10, 30 });
            //servoMotions.Add(2, new int[] { 110, 20 });
            //servoMotions.Add(3, new int[] { 45, 40 });
            //robot.PerformMotion(servoMotions);
            

            //foreach (var servo in robot.AllJoints)
            //{
            //    sb.AppendLine("Servo " + servo.Id.ToString() + " is in " + servo.Angle.ToString() + " and its speed is " + servo.Speed.ToString());
            //}


            //string res = robot.ManipulateV_Rep();
            //if (!String.IsNullOrEmpty(res))
            //{
            //    if (!bk1.IsBusy)
            //    {
            //        bk1.RunWorkerAsync(sb);
            //    }
            //}
        }

        private string StartVRepSimulation(BackgroundWorker worker)
        {
            Bioloid robot = new Bioloid();

            robot.SetVRepPort(Convert.ToInt32(txtPort.Text.ToString()));

            string res = robot.ManipulateV_Rep(worker);
            if (!String.IsNullOrEmpty(res))
            {
                return res;
            }
            else
            {
                return String.Empty;
            }
        }

        private void bk1_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            sb.AppendLine((string)e.Result);
            txtVRepMessage.Text = sb.ToString();
            btnStartSimulation.Enabled = true;
        }
    }
}
