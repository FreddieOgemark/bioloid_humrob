﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BioloidRobot
{
    public class Sensor
    {
        public Sensor()
        {

        }

        public int Id { get; set; }
        public string Name { get; set; }
        public SensorType Type { get; set; }
    }

    public enum SensorType : int
    {
        Gyroscope=1,
        Infrared,
        Voice
    }
}
