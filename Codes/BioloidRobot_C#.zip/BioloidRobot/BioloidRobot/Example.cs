﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BioloidRobot
{
    class Example
    {
//        int clientID = simxStart("127.0.0.1", portNb, true, true, 2000, 5);
//        int clientID2 = simxStart("127.0.0.1", portNb + 1000, true, true, 2000, 5);
//if ((clientID!=-1)&&(clientID2!=-1))
//{
//   int driveBackStartTime = -99000;
//        float motorSpeeds[2];
//   while ( (simxGetConnectionId(clientID)!=-1)&&(simxGetConnectionId(clientID2)!=-1) )
//   {
//      char sensorTrigger = 0;
//      if (simxReadProximitySensor(clientID, sensorHandle,&sensorTrigger, NULL, NULL, NULL, simx_opmode_continuous)==simx_error_noerror)
//      { // We succeeded at reading the proximity sensor
//         printf("ProxSensor, from client1: %i\n", int(sensorTrigger));
//         int simulationTime = simxGetLastCmdTime(clientID);
//         if (simulationTime-driveBackStartTime<3000)
//         { // driving backwards while slightly turning:
//            motorSpeeds[0]=-3.1415f*0.5f;
//            motorSpeeds[1]=-3.1415f*0.25f;
//         }
//         else
//         { // going forward:
//            motorSpeeds[0]=3.1415f;
//            motorSpeeds[1]=3.1415f;
//            if (sensorTrigger)
//               driveBackStartTime=simulationTime; // We detected something, and start the backward mode
//         }
//         simxSetJointTargetVelocity(clientID, leftMotorHandle, motorSpeeds[0], simx_opmode_oneshot);
//         simxSetJointTargetVelocity(clientID, rightMotorHandle, motorSpeeds[1], simx_opmode_oneshot);         
//      }
//      char sensorTrigger2 = 0;
//      if (simxReadProximitySensor(clientID2, sensorHandle,&sensorTrigger2, NULL, NULL, NULL, simx_opmode_continuous)==simx_error_noerror)
//      { // We succeeded at reading the proximity sensor
//         printf("ProxSensor, from client2: %i\n", int(sensorTrigger2));
//      }
//      extApi_sleepMs(5);
//   }
//   simxFinish(clientID);
//}
    }
}
