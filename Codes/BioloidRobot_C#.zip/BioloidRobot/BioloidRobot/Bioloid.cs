﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using remoteApiNETWrapper;
using System.Runtime.InteropServices;
using System.Threading;
using System.ComponentModel;
//using Dynamixel;

namespace BioloidRobot
{
    public class Bioloid
    {
        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern void simxGetObjectHandle(int clientID, string objectName, out int handle, simx_opmode opmode);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxStart(string ip, int port, bool waitForConnection, bool reconnectOnDisconnect, int timeoutMS, int cycleTimeMS);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern simx_error simxGetObjectPosition(int clientID, int jointHandle, int relativeToHandle, float[] positions, simx_opmode opmode);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern simx_error simxGetJointPosition(int clientID, int jointHandle, ref float targetPosition, simx_opmode opmode);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern simx_error simxSetJointTargetPosition(int clientID, int jointHandle, float targetPosition, simx_opmode opmode);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern simx_error simxGetObjectFloatParameter(int clientID, int objectHandle, int parameterID, ref float parameterValue, simx_opmode opmode);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern simx_error simxFinish(int clientID);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxGetObjectGroupData(int clientID, int objectType, int dataType, out int handlesCount, out int[] handles, out int intDataCount, out int[] intData, out int floatDataCount, out float[] floatData, out int stringDataCount, out char[] stringData, simx_opmode opMode);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxStartSimulation(int clientID, simx_opmode opMode);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxGetConnectionId(int clientID);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxSetJointPosition(int clientID, int jointHandle, float position, simx_opmode opMode);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern simx_error simxSetObjectPosition(int clientID, int objectHandle, int relativeToObjectHandle, float[] position, simx_opmode opMode);

        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxPauseSimulation(int clientID, simx_opmode opMode);


        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxPauseCommunication(int clientID, int pause);


        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxSynchronous(int clientID, bool enable);


        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxSynchronousTrigger(int clientID);


        [DllImport("remoteApi.dll", CallingConvention = CallingConvention.Cdecl)]
        public static extern int simxStopSimulation(int clientID, simx_opmode opMode);


        public Bioloid()
        {
            AllJoints = new List<Joint>();
            AllSensors = new List<Sensor>();
        }

        public List<Joint> AllJoints { get; set; }
        public List<Sensor> AllSensors { get; set; }

        public int V_RepPort { get; set; }

        public void AddJoint(int jointId, int jointAngle, int jointSpeed, bool isFixed)
        {
            if (AllJoints != null)
            {
                AllJoints.Add(new Joint()
                {
                    Id = jointId,
                    Angle = jointAngle,
                    Speed = jointSpeed,
                    Fixed = isFixed
                });
            }
        }

        public void AddSensor(int sensorId, string sensorName, SensorType sensorType)
        {
            if (AllSensors != null)
            {
                AllSensors.Add(new Sensor()
                {
                    Id = sensorId,
                    Name = sensorName,
                    Type = sensorType
                });
            }
        }

        public void SetVRepPort(int PortNo)
        {
            this.V_RepPort = PortNo;
        }

        /// <summary>
        /// This is important to put the servos in the dictionary in order to start the motion to the end
        /// </summary>
        /// <param name="servosProperties"></param>
        public void PerformMotion(Dictionary<int, int[]> servosProperties)
        {
            //foreach (int id in servosProperties.Keys)
            //{
            //    //Joint j = (from jo in AllJoints
            //    //          where jo.Id == id
            //    //          select jo).FirstOrDefault<Joint>();
            //    Joint j = AllJoints.Where(jo => jo.Id == id).FirstOrDefault<Joint>();
            //    if (j != null)
            //    {
            //        int[] props;
            //        bool succeedToGetValue = servosProperties.TryGetValue(id, out props);
            //        if (succeedToGetValue)
            //        {
            //            //this.AllJoints[0].Angle = props[0];
            //            //this.AllJoints[0].Speed = props[1];
            //            j.Angle = props[0];
            //            j.Speed= props[1];

            //            //VREPSetBlock vs = new VREPSetBlock(1);
            //            //VREPWrapper.simxStart()
            //            //int clientID = VREPWrapper.simxStart("127.0.0.1", 19999, true, true, 5000, 5);

            //            /* To change the port number you should change the remoteApiConnections.txt file in the V-Rep installed directory */
            //            int clientID = simxStart("127.0.0.1", 19997, true, true, 5000, 5);

            //            /* starting simulation */
            //            simxStartSimulation(clientID, simx_opmode.oneshot);

            //            simx_error err;

            //            int objHandle;
            //            simxGetObjectHandle(clientID, "Bioloid#", out objHandle, simx_opmode.oneshot_wait);

            //            float x = 0.0F, y = 0.0F, z = 0.0F;
            //            float[] pos = new float[3] { x, y, z };
            //            err = simxGetObjectPosition(clientID, objHandle, -1, pos, simx_opmode.streaming);

            //            int counter = 0;
            //            int j5;
            //            simxGetObjectHandle(clientID, "Joint5#", out j5, simx_opmode.oneshot_wait);
            //            int j14;
            //            simxGetObjectHandle(clientID, "Joint14#", out j14, simx_opmode.oneshot_wait);
            //            int j13;
            //            simxGetObjectHandle(clientID, "Joint13#", out j13, simx_opmode.oneshot_wait);

            //            while (simxGetConnectionId(clientID) != -1)
            //            {
            //                //if (si)
            //                counter++;
            //                simxGetObjectHandle(clientID, "Bioloid#", out objHandle, simx_opmode.oneshot_wait);
            //                err = simxGetObjectPosition(clientID, objHandle, -1, pos, simx_opmode.buffer);
            //                Console.WriteLine("connected");
            //                if (counter > 0 && counter<10)
            //                {

            //                    simxPauseSimulation(clientID, simx_opmode.oneshot);

            //                    float[] newPos = { x=0.0F, y=0.0F, z=0.0F };

            //                    simxSetJointPosition(clientID, j5, 001.1F, simx_opmode.streaming);
            //                    simxSetJointPosition(clientID, j13, 000.5F, simx_opmode.streaming);
            //                    simxSetJointPosition(clientID, j14, -000.5F, simx_opmode.streaming);
            //                    Thread.Sleep(1000);
            //                    simxStartSimulation(clientID, simx_opmode.oneshot);
            //                }
            //                else
            //                {
            //                    break;
            //                }
            //            }

            //            //float[] pos= { 10, 10, 10 };
            //            //err = simxGetObjectPosition(clientID, objHandle, -1, pos, simx_opmode.streaming);
            //            //float targetPos = 0F;
            //            //err = simxGetJointPosition(clientID, objHandle, ref targetPos, simx_opmode.streaming);

            //            ////simxSetJointTargetPosition(clientID, objHandle, 100.1F, simx_opmode.oneshot);
            //            //float xVelocity = 0.0F;
            //            //simxGetObjectFloatParameter(clientID, objHandle, 11, ref xVelocity, simx_opmode.streaming);



            //            //Console.WriteLine("current x velocity " + xVelocity.ToString());



            //            ////simxInt simxGetObjectGroupData(simxInt clientID, simxInt objectType, simxInt dataType, simxInt* handlesCount, simxInt** handles, simxInt* intDataCount, simxInt** intData, simxInt* floatDataCount, simxFloat** floatData, simxInt* stringDataCount, simxChar** stringData, simxInt operationMode)

            //            ////simxGetObjectGroupData(clientID, )

            //            simxFinish(clientID);

            //        }
            //    }
            //}
        }

        public string ManipulateV_Rep(BackgroundWorker worker)
        {
            string res = String.Empty;
            int clientID = simxStart("127.0.0.1", V_RepPort, true, true, 5000, 5);
            if (clientID == -1)
            {
                res = "Connection could not be established! Please check the port number!";
                return res;
            }

            simxStartSimulation(clientID, simx_opmode.oneshot);

            worker.ReportProgress(1);

            /* object handles */
            int robotVerticalHandle;
            simxGetObjectHandle(clientID, "Pivot#", out robotVerticalHandle, simx_opmode.oneshot_wait);//.oneshot_wait);
            int robotHorizontalHandle;
            simxGetObjectHandle(clientID, "HelperArm#", out robotHorizontalHandle, simx_opmode.oneshot_wait);
            int robotHandle;
            simxGetObjectHandle(clientID, "Bioloid#", out robotHandle, simx_opmode.oneshot_wait);
            int j5;
            simxGetObjectHandle(clientID, "Joint5#", out j5, simx_opmode.oneshot_wait);
            int j14;
            simxGetObjectHandle(clientID, "Joint14#", out j14, simx_opmode.oneshot_wait);
            int j13;
            simxGetObjectHandle(clientID, "Joint13#", out j13, simx_opmode.oneshot_wait);
            /* end of object handles */

            int counter = 0;

            /*** Set the initial position of different moving parts ***/
            float x1, y1, z1;
            float x2, y2, z2;
            float x3, y3, z3;
            /* for pivot 1.0, 0.0, 0.1250 */
            x1 = 1.0F; y1 = 0.0F; z1 = 0.1250F;

            /* for HelperArm 1.0, 0.0, 0.1250*/
            x2 = 0.75F; y2 = 0.0F; z2 = 0.25F;

            /* for Bioloid 1.0, 0.0, 0.1250*/
            x3 = 0.0F; y3 = 0.0F; z3 = 0.30F;
            /*** End of initial position definition ***/

            while (simxGetConnectionId(clientID) != -1)
            {
                if (counter > 2000)
                {
                    simxSynchronous(clientID, true);

                    y1 += 0.1F;
                    y2 += 0.1F;
                    y3 += 0.1F;
                    float[] newPos1 = { x1, y1, z1 };
                    float[] newPos2 = { x2, y2, z2 };
                    float[] newPos3 = { x3, y3, z3 };

                    simxSetJointPosition(clientID, j5, 001.1F, simx_opmode.streaming);//.streaming);
                    simxSetJointPosition(clientID, j13, 000.5F, simx_opmode.streaming);
                    simxSetJointPosition(clientID, j14, -000.5F, simx_opmode.streaming);

                    simxSetObjectPosition(clientID, robotVerticalHandle, -1, newPos1, simx_opmode.oneshot);
                    simxSetObjectPosition(clientID, robotHorizontalHandle, -1, newPos2, simx_opmode.oneshot);
                    simxSetObjectPosition(clientID, robotHandle, -1, newPos3, simx_opmode.oneshot);

                    Thread.Sleep(500);
                    simxSynchronousTrigger(clientID);

                    if (counter > 2020)
                    {
                        simxSynchronous(clientID, false);
                        simxStopSimulation(clientID, simx_opmode.oneshot_wait);
                        break;
                    }
                }
                counter++;
                //worker.ReportProgress(counter);
                //Console.WriteLine(counter);
            }
            simxFinish(clientID);
            res = "Simulation is finished now!";
            return res;
        }
    }
}
