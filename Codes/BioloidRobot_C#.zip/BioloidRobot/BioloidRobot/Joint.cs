﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BioloidRobot
{
    public class Joint
    {
        public Joint()
        {

        }

        public int Id { get; set; }
        public int Angle { get; set; }
        public int Speed { get; set; }
        public bool Fixed { get; set; }
    }
}
