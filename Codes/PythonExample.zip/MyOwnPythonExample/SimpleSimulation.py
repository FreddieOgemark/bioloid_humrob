try:
    import vrep
except:
    print ('--------------------------------------------------------------')
    print ('"vrep.py" could not be imported. This means very probably that')
    print ('either "vrep.py" or the remoteApi library could not be found.')
    print ('Make sure both are in the same folder as this file,')
    print ('or appropriately adjust the file "vrep.py"')
    print ('--------------------------------------------------------------')
    print ('')

import time

print ('Program started')
vrep.simxFinish(-1) # just in case, close all opened connections
clientID=vrep.simxStart('127.0.0.1',19997,True,True,5000,5) # Connect to V-REP
if clientID!=-1:
    print ('Connected to remote API server')

    vrep.simxStartSimulation(clientID, vrep.simx_opmode_oneshot)
    res, pivotHandle=vrep.simxGetObjectHandle(clientID,'Pivot#', vrep.simx_opmode_oneshot_wait)

    # Pivot initial coordinations
    x1,y1,z1 = 1.0, 0.0, 0.1250
    counter = 0
    # number y1
    res=vrep.simxSynchronous(clientID, True)
    while True:
        y1 = y1 + 0.1
        pos = [x1,y1,z1]
        res = vrep.simxSetObjectPosition(clientID, pivotHandle, -1, pos, vrep.simx_opmode_oneshot)
        time.sleep(.5)
        res = vrep.simxSynchronousTrigger(clientID)
        if counter > 20:
            vrep.simxSynchronous(clientID, False)
            res = vrep.simxStopSimulation(clientID, vrep.simx_opmode_oneshot)
            time.sleep(.5)
            break
        
        counter = counter + 1

    time.sleep(.5)
    vrep.simxFinish(clientID)
    print ('Simulation has finished')
