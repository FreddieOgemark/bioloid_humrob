﻿//
// This software was written and developed by Scott Ferguson.
// The current version can be found at http://www.forestmoon.com/Software/.
// Comments and suggestions are encouraged and can be sent to mailto:contact@forestmoon.com?subject=Software.
// This free software is distributed under the GNU General Public License.
// See http://www.gnu.org/licenses/gpl.html for details.
// This license restricts your usage of the software in derivative works.
//
// Uncomment the #define for EchoToConsole to enable echoing of Dynamixel comm to the debug window.
//#define EchoToConsole

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO.Ports;
using Dynamixel;
using System.IO;

namespace DynaCommander
{
	public partial class mainForm : Form
	{
		private SerialPort Port;				// serial port with Dynamixel controller
		private DynamixelNetwork DynNet;		// the Dynamixel network

		public mainForm()
		{
			InitializeComponent();
		}

		private void mainForm_Shown(object sender, EventArgs e)
		{
			if (!Properties.Settings.Default.SettingsUpgraded)
			{
				// transfer settings from one version to the next
				Properties.Settings.Default.Upgrade();
				Properties.Settings.Default.SettingsUpgraded = true;
			}
			// get the saved port preferences
			string PortName = Properties.Settings.Default.PortName;
			string BaudRate = Properties.Settings.Default.BaudRate;
			bool UseDialog = Control.ModifierKeys == Keys.Shift;
			// configure the port
			Port = SelectPort.ConfigurePort(ref PortName, ref BaudRate, ref UseDialog);
			if (Port == null)
			{
				// shutdown if dialog is canceled
				Close();
				return;
			}
			if (UseDialog)
			{
				// dialog was invoked, save the port preferences
				Properties.Settings.Default.PortName = PortName;
				Properties.Settings.Default.BaudRate = BaudRate;
				Properties.Settings.Default.Save();
			}

			EchoComm = Properties.Settings.Default.EchoComm;
			EchoChars = Properties.Settings.Default.EchoChars;

			// initialize the Dynamixel network
			EchoStream str = new EchoStream(Port.BaseStream);
			str.Echo += new EventHandler(str_Echo);
#if EchoToConsole
			str.Echo += new EventHandler(str_EchoConsole);
#endif
			DynNet = new DynamixelNetwork(str);
			DynNet.DynamixelError += new DynamixelInterface.DynamixelErrorHandler(DynNet_DynamixelError);
			try
			{
				DynNet.EnterTossMode();
			}
			catch (Exception exc)
			{
				MessageBox.Show(exc.Message, "Error entering Toss Mode");
				Close();
				return;
			}

			textBoxScanFrom.Text = Properties.Settings.Default.ScanFrom.ToString();
			textBoxScanTo.Text = Properties.Settings.Default.ScanTo.ToString();
			Scan();
		}

		void DynNet_DynamixelError(object sender, DynamixelInterface.DynamixelErrorArgs e)
		{
			string s = string.Join(",", DynamixelInterface.ErrorText(e.ErrorStatus).ToArray());
			listBoxEcho.SelectedIndex = listBoxEcho.Items.Add("Dynamixel Error: " + s);
			EchoForce = true;
		}

		bool Writing;

		bool EchoForce;

		bool EchoComm
		{
			get { return checkBoxEcho.Checked; }
			set { checkBoxEcho.Checked = value; }
		}

		bool EchoChars
		{
			get { return checkBoxChars.Checked; }
			set { checkBoxChars.Checked = value; }
		}

		void str_Echo(object sender, EventArgs e)
		{
			if (!EchoComm)
				return;
			EchoStream str = sender as EchoStream;
			int cnt = listBoxEcho.Items.Count;
			string s;
			if (EchoChars && str.EchoByte >= 0x20 && str.EchoByte <= 0x7F)
				s = string.Format("{0} ", (char)str.EchoByte);
			else
				s = string.Format("0x{0:X2} ", str.EchoByte);
			if (str.Writing != Writing || cnt == 0 || EchoForce)
			{
				EchoForce = false;
				Writing = str.Writing;
				if (Writing)
					listBoxEcho.Items.Add("-> " + s);
				else
					listBoxEcho.Items.Add("<- " + s);
				listBoxEcho.SelectedIndex = cnt;
				if (cnt >= 100)
					listBoxEcho.Items.RemoveAt(0);
			}
			else
			{
				listBoxEcho.Items[cnt-1] = listBoxEcho.SelectedItem + s;
			}
		}

#if EchoToConsole
		void str_EchoConsole(object sender, EventArgs e)
		{
			EchoStream str = sender as EchoStream;
			if (str.Writing != Writing)
			{
				Writing = str.Writing;
				if (Writing)
					Console.Write("\r\n-> ");
				else
					Console.Write("\r\n<- ");
			}
			if (EchoChars && str.EchoByte >= 0x20 && str.EchoByte <= 0x7F)
				Console.Write("{0} ", (char)str.EchoByte);
			else
				Console.Write("0x{0:X2} ", str.EchoByte);
		}
#endif

		private void Scan()
		{
			// fetch the starting scan ID from the textbox
			int From = 0;
			try
			{
				From = int.Parse(textBoxScanFrom.Text);
				if (From < 0 || From >= DynamixelInterface.BroadcastId)
					throw new Exception(string.Format("From value must be in the range from 0 to {0}", DynamixelInterface.BroadcastId - 1));
			}
			catch (Exception exc)
			{
				MessageBox.Show(exc.Message);
				return;
			}
			// fetch the ending scan ID from the textbox
			int To = 0;
			try
			{
				To = int.Parse(textBoxScanTo.Text);
				if (To < From || To >= DynamixelInterface.BroadcastId)
					throw new Exception(string.Format("From value must be in the range from {0} to {1}", From, DynamixelInterface.BroadcastId - 1));
			}
			catch (Exception exc)
			{
				MessageBox.Show(exc.Message);
				return;
			}
			// persist the current values
			Properties.Settings.Default.ScanFrom = From;
			Properties.Settings.Default.ScanTo = To;
			Properties.Settings.Default.Save();
			// update the UI with sanitized values
			textBoxScanFrom.Text = From.ToString();
			textBoxScanTo.Text = To.ToString();
			// fill the listbox with discovered Dynamixels
			listBoxDynamixels.Items.Clear();
			DynNet.Scan(From, To);
			foreach (Dynamixel.Dynamixel dyn in DynNet.Dynamixels)
			{
				dyn.Synchronized = false;
				listBoxDynamixels.Items.Add(dyn);
			}
			// select the first one
			if (listBoxDynamixels.Items.Count > 0)
				listBoxDynamixels.SelectedIndex = 0;
		}

		private void listBoxDynamixels_SelectedIndexChanged(object sender, EventArgs e)
		{
			Dynamixel.Dynamixel dyn = listBoxDynamixels.SelectedItem as Dynamixel.Dynamixel;
			if (dyn == null)
				return;
			dyn.ReadAll();
			propertyGrid.SelectedObject = dyn;
			trackBarPosition.Value = dyn.GoalPosition;
		}

		private void buttonRefresh_Click(object sender, EventArgs e)
		{
			propertyGrid.Refresh();
		}

		private void trackBarPosition_Scroll(object sender, EventArgs e)
		{
			Dynamixel.Dynamixel dyn = listBoxDynamixels.SelectedItem as Dynamixel.Dynamixel;
			if (dyn == null)
				return;
			try
			{
				dyn.GoalPosition = trackBarPosition.Value;
			}
			catch (Exception exc)
			{
				listBoxEcho.SelectedIndex = listBoxEcho.Items.Add(exc.Message);
				EchoForce = true;
			}
		}

		private void buttonScan_Click(object sender, EventArgs e)
		{
			Scan();
		}

		private void trackBarPosition_ValueChanged(object sender, EventArgs e)
		{
			labelGoal.Text = trackBarPosition.Value.ToString();
		}

		private void mainForm_FormClosed(object sender, FormClosedEventArgs e)
		{
			DynNet.DumpStatistics();
		}

		private void propertyGrid_PropertyValueChanged(object s, PropertyValueChangedEventArgs e)
		{
			if (e.ChangedItem.Label == "Id")
			{
				// update the item in the listbox to reflect the Id change
				Dynamixel.Dynamixel CurDyn = (Dynamixel.Dynamixel)listBoxDynamixels.SelectedItem;
				int index = listBoxDynamixels.SelectedIndex;
				listBoxDynamixels.Items[index] = CurDyn;
				listBoxDynamixels.SelectedIndex = index;
			}
		}

		private void buttonReset_Click(object sender, EventArgs e)
		{
			if (MessageBox.Show("Reset of a Dynamixel resets all registers to factory default values, including setting the ID to 1.\r\n\r\nContinue?", "WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation) != DialogResult.Yes)
				return;
			Dynamixel.Dynamixel CurDyn = (Dynamixel.Dynamixel)listBoxDynamixels.SelectedItem;
			try
			{
				// reset the Dynamixel
				CurDyn.Reset();
			}
			catch (Exception exc)
			{
				MessageBox.Show(exc.Message, "Error reseting Dynamixel");
				return;
			}
			// reflect changes in the grid
			propertyGrid.Refresh();
			// update the item in the listbox to reflect the Id change
			int index = listBoxDynamixels.SelectedIndex;
			listBoxDynamixels.Items[index] = CurDyn;
			listBoxDynamixels.SelectedIndex = index;
		}

		private void checkBoxEcho_CheckedChanged(object sender, EventArgs e)
		{
			Properties.Settings.Default.EchoComm = EchoComm;
			Properties.Settings.Default.Save();
		}

		private void checkBoxChars_CheckedChanged(object sender, EventArgs e)
		{
			Properties.Settings.Default.EchoChars = EchoChars;
			Properties.Settings.Default.Save();
		}

		private void clearToolStripMenuItem_Click(object sender, EventArgs e)
		{
			listBoxEcho.Items.Clear();
		}

		private void buttonStats_Click(object sender, EventArgs e)
		{
			List<string> list = DynNet.DumpStatistics();
			foreach (string s in list)
			{
				listBoxEcho.Items.Add(s);
			}
			listBoxEcho.SelectedIndex = listBoxEcho.Items.Count - 1;
			EchoForce = true;
		}
	}
}
