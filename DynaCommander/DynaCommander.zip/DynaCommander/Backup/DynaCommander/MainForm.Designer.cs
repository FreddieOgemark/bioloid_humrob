﻿namespace DynaCommander
{
	partial class mainForm
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(mainForm));
			this.splitContainer1 = new System.Windows.Forms.SplitContainer();
			this.checkBoxChars = new System.Windows.Forms.CheckBox();
			this.checkBoxEcho = new System.Windows.Forms.CheckBox();
			this.listBoxEcho = new System.Windows.Forms.ListBox();
			this.buttonReset = new System.Windows.Forms.Button();
			this.labelGoal = new System.Windows.Forms.Label();
			this.textBoxScanTo = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.textBoxScanFrom = new System.Windows.Forms.TextBox();
			this.buttonScan = new System.Windows.Forms.Button();
			this.trackBarPosition = new System.Windows.Forms.TrackBar();
			this.buttonRefresh = new System.Windows.Forms.Button();
			this.listBoxDynamixels = new System.Windows.Forms.ListBox();
			this.propertyGrid = new System.Windows.Forms.PropertyGrid();
			this.contextMenuStripEcho = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.clearToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.buttonStats = new System.Windows.Forms.Button();
			this.splitContainer1.Panel1.SuspendLayout();
			this.splitContainer1.Panel2.SuspendLayout();
			this.splitContainer1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.trackBarPosition)).BeginInit();
			this.contextMenuStripEcho.SuspendLayout();
			this.SuspendLayout();
			// 
			// splitContainer1
			// 
			this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.splitContainer1.Location = new System.Drawing.Point(0, 0);
			this.splitContainer1.Name = "splitContainer1";
			// 
			// splitContainer1.Panel1
			// 
			this.splitContainer1.Panel1.Controls.Add(this.buttonStats);
			this.splitContainer1.Panel1.Controls.Add(this.checkBoxChars);
			this.splitContainer1.Panel1.Controls.Add(this.checkBoxEcho);
			this.splitContainer1.Panel1.Controls.Add(this.listBoxEcho);
			this.splitContainer1.Panel1.Controls.Add(this.buttonReset);
			this.splitContainer1.Panel1.Controls.Add(this.labelGoal);
			this.splitContainer1.Panel1.Controls.Add(this.textBoxScanTo);
			this.splitContainer1.Panel1.Controls.Add(this.label1);
			this.splitContainer1.Panel1.Controls.Add(this.textBoxScanFrom);
			this.splitContainer1.Panel1.Controls.Add(this.buttonScan);
			this.splitContainer1.Panel1.Controls.Add(this.trackBarPosition);
			this.splitContainer1.Panel1.Controls.Add(this.buttonRefresh);
			this.splitContainer1.Panel1.Controls.Add(this.listBoxDynamixels);
			// 
			// splitContainer1.Panel2
			// 
			this.splitContainer1.Panel2.Controls.Add(this.propertyGrid);
			this.splitContainer1.Size = new System.Drawing.Size(902, 663);
			this.splitContainer1.SplitterDistance = 406;
			this.splitContainer1.TabIndex = 0;
			// 
			// checkBoxChars
			// 
			this.checkBoxChars.AutoSize = true;
			this.checkBoxChars.Location = new System.Drawing.Point(310, 235);
			this.checkBoxChars.Name = "checkBoxChars";
			this.checkBoxChars.Size = new System.Drawing.Size(84, 21);
			this.checkBoxChars.TabIndex = 11;
			this.checkBoxChars.Text = "as chars";
			this.checkBoxChars.UseVisualStyleBackColor = true;
			this.checkBoxChars.CheckedChanged += new System.EventHandler(this.checkBoxChars_CheckedChanged);
			// 
			// checkBoxEcho
			// 
			this.checkBoxEcho.AutoSize = true;
			this.checkBoxEcho.Location = new System.Drawing.Point(199, 235);
			this.checkBoxEcho.Name = "checkBoxEcho";
			this.checkBoxEcho.Size = new System.Drawing.Size(105, 21);
			this.checkBoxEcho.TabIndex = 10;
			this.checkBoxEcho.Text = "Echo Comm";
			this.checkBoxEcho.UseVisualStyleBackColor = true;
			this.checkBoxEcho.CheckedChanged += new System.EventHandler(this.checkBoxEcho_CheckedChanged);
			// 
			// listBoxEcho
			// 
			this.listBoxEcho.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
						| System.Windows.Forms.AnchorStyles.Left)
						| System.Windows.Forms.AnchorStyles.Right)));
			this.listBoxEcho.ContextMenuStrip = this.contextMenuStripEcho;
			this.listBoxEcho.Font = new System.Drawing.Font("Lucida Sans Typewriter", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.listBoxEcho.FormattingEnabled = true;
			this.listBoxEcho.HorizontalScrollbar = true;
			this.listBoxEcho.ItemHeight = 15;
			this.listBoxEcho.Location = new System.Drawing.Point(12, 277);
			this.listBoxEcho.Name = "listBoxEcho";
			this.listBoxEcho.Size = new System.Drawing.Size(382, 379);
			this.listBoxEcho.TabIndex = 9;
			// 
			// buttonReset
			// 
			this.buttonReset.Location = new System.Drawing.Point(246, 155);
			this.buttonReset.Name = "buttonReset";
			this.buttonReset.Size = new System.Drawing.Size(75, 23);
			this.buttonReset.TabIndex = 8;
			this.buttonReset.Text = "Reset";
			this.buttonReset.UseVisualStyleBackColor = true;
			this.buttonReset.Click += new System.EventHandler(this.buttonReset_Click);
			// 
			// labelGoal
			// 
			this.labelGoal.Location = new System.Drawing.Point(123, 239);
			this.labelGoal.Name = "labelGoal";
			this.labelGoal.Size = new System.Drawing.Size(50, 17);
			this.labelGoal.TabIndex = 7;
			this.labelGoal.Text = "to";
			this.labelGoal.TextAlign = System.Drawing.ContentAlignment.TopCenter;
			// 
			// textBoxScanTo
			// 
			this.textBoxScanTo.Location = new System.Drawing.Point(300, 117);
			this.textBoxScanTo.Name = "textBoxScanTo";
			this.textBoxScanTo.Size = new System.Drawing.Size(32, 22);
			this.textBoxScanTo.TabIndex = 6;
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(274, 122);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(20, 17);
			this.label1.TabIndex = 5;
			this.label1.Text = "to";
			// 
			// textBoxScanFrom
			// 
			this.textBoxScanFrom.Location = new System.Drawing.Point(236, 117);
			this.textBoxScanFrom.Name = "textBoxScanFrom";
			this.textBoxScanFrom.Size = new System.Drawing.Size(32, 22);
			this.textBoxScanFrom.TabIndex = 4;
			// 
			// buttonScan
			// 
			this.buttonScan.Location = new System.Drawing.Point(246, 88);
			this.buttonScan.Name = "buttonScan";
			this.buttonScan.Size = new System.Drawing.Size(75, 23);
			this.buttonScan.TabIndex = 3;
			this.buttonScan.Text = "Scan";
			this.buttonScan.UseVisualStyleBackColor = true;
			this.buttonScan.Click += new System.EventHandler(this.buttonScan_Click);
			// 
			// trackBarPosition
			// 
			this.trackBarPosition.LargeChange = 16;
			this.trackBarPosition.Location = new System.Drawing.Point(129, 12);
			this.trackBarPosition.Maximum = 1023;
			this.trackBarPosition.Name = "trackBarPosition";
			this.trackBarPosition.Orientation = System.Windows.Forms.Orientation.Vertical;
			this.trackBarPosition.Size = new System.Drawing.Size(56, 224);
			this.trackBarPosition.TabIndex = 2;
			this.trackBarPosition.TickFrequency = 32;
			this.trackBarPosition.ValueChanged += new System.EventHandler(this.trackBarPosition_ValueChanged);
			this.trackBarPosition.Scroll += new System.EventHandler(this.trackBarPosition_Scroll);
			// 
			// buttonRefresh
			// 
			this.buttonRefresh.Location = new System.Drawing.Point(246, 49);
			this.buttonRefresh.Name = "buttonRefresh";
			this.buttonRefresh.Size = new System.Drawing.Size(75, 23);
			this.buttonRefresh.TabIndex = 1;
			this.buttonRefresh.Text = "Refresh";
			this.buttonRefresh.UseVisualStyleBackColor = true;
			this.buttonRefresh.Click += new System.EventHandler(this.buttonRefresh_Click);
			// 
			// listBoxDynamixels
			// 
			this.listBoxDynamixels.FormattingEnabled = true;
			this.listBoxDynamixels.ItemHeight = 16;
			this.listBoxDynamixels.Location = new System.Drawing.Point(23, 12);
			this.listBoxDynamixels.Name = "listBoxDynamixels";
			this.listBoxDynamixels.Size = new System.Drawing.Size(67, 244);
			this.listBoxDynamixels.TabIndex = 0;
			this.listBoxDynamixels.SelectedIndexChanged += new System.EventHandler(this.listBoxDynamixels_SelectedIndexChanged);
			// 
			// propertyGrid
			// 
			this.propertyGrid.Dock = System.Windows.Forms.DockStyle.Fill;
			this.propertyGrid.Location = new System.Drawing.Point(0, 0);
			this.propertyGrid.Name = "propertyGrid";
			this.propertyGrid.PropertySort = System.Windows.Forms.PropertySort.Alphabetical;
			this.propertyGrid.Size = new System.Drawing.Size(492, 663);
			this.propertyGrid.TabIndex = 0;
			this.propertyGrid.ToolbarVisible = false;
			this.propertyGrid.PropertyValueChanged += new System.Windows.Forms.PropertyValueChangedEventHandler(this.propertyGrid_PropertyValueChanged);
			// 
			// contextMenuStripEcho
			// 
			this.contextMenuStripEcho.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.clearToolStripMenuItem});
			this.contextMenuStripEcho.Name = "contextMenuStripEcho";
			this.contextMenuStripEcho.Size = new System.Drawing.Size(113, 28);
			// 
			// clearToolStripMenuItem
			// 
			this.clearToolStripMenuItem.Name = "clearToolStripMenuItem";
			this.clearToolStripMenuItem.Size = new System.Drawing.Size(112, 24);
			this.clearToolStripMenuItem.Text = "Clear";
			this.clearToolStripMenuItem.Click += new System.EventHandler(this.clearToolStripMenuItem_Click);
			// 
			// buttonStats
			// 
			this.buttonStats.Location = new System.Drawing.Point(246, 195);
			this.buttonStats.Name = "buttonStats";
			this.buttonStats.Size = new System.Drawing.Size(75, 23);
			this.buttonStats.TabIndex = 12;
			this.buttonStats.Text = "Stats";
			this.buttonStats.UseVisualStyleBackColor = true;
			this.buttonStats.Click += new System.EventHandler(this.buttonStats_Click);
			// 
			// mainForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(902, 663);
			this.Controls.Add(this.splitContainer1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MaximizeBox = false;
			this.Name = "mainForm";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "DynaCommander";
			this.Shown += new System.EventHandler(this.mainForm_Shown);
			this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.mainForm_FormClosed);
			this.splitContainer1.Panel1.ResumeLayout(false);
			this.splitContainer1.Panel1.PerformLayout();
			this.splitContainer1.Panel2.ResumeLayout(false);
			this.splitContainer1.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.trackBarPosition)).EndInit();
			this.contextMenuStripEcho.ResumeLayout(false);
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.SplitContainer splitContainer1;
		private System.Windows.Forms.ListBox listBoxDynamixels;
		private System.Windows.Forms.PropertyGrid propertyGrid;
		private System.Windows.Forms.Button buttonRefresh;
		private System.Windows.Forms.TrackBar trackBarPosition;
		private System.Windows.Forms.TextBox textBoxScanTo;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBoxScanFrom;
		private System.Windows.Forms.Button buttonScan;
		private System.Windows.Forms.Label labelGoal;
		private System.Windows.Forms.Button buttonReset;
		private System.Windows.Forms.ListBox listBoxEcho;
		private System.Windows.Forms.CheckBox checkBoxEcho;
		private System.Windows.Forms.CheckBox checkBoxChars;
		private System.Windows.Forms.ContextMenuStrip contextMenuStripEcho;
		private System.Windows.Forms.ToolStripMenuItem clearToolStripMenuItem;
		private System.Windows.Forms.Button buttonStats;
	}
}

